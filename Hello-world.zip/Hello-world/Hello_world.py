from flask import Flask, render_template
app = Flask(__name__)                    
@app.route('/')                          
def hello_world():
  return render_template('index.html')    
app.run(debug=True)                       

#local location in computer to easily copy/paste into terminal if the VS Code debugger breaks:
#python /Users/Joel/Desktop/DojoAssignments/Python/Week-1/Day-4/Hello-world/Hello_world.py